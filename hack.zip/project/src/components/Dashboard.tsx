import React, { useState, useEffect } from 'react';
import { Camera, Calendar, User, ExternalLink, Download, Trash2, RefreshCw } from 'lucide-react';
import { getSessions, debugStorage } from '../utils/storage';
import { CaptureSession } from '../types';

export const Dashboard: React.FC = () => {
  const [sessions, setSessions] = useState<CaptureSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadSessions = () => {
    console.log('Loading sessions...');
    debugStorage();
    const allSessions = getSessions();
    console.log('Loaded sessions:', allSessions);
    setSessions(allSessions.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    setIsLoading(false);
  };

  useEffect(() => {
    loadSessions();
    // Refresh data every 5 seconds
    const interval = setInterval(loadSessions, 5000);
    return () => clearInterval(interval);
  }, []);

  const downloadPhoto = (dataUrl: string, timestamp: string) => {
    try {
      const link = document.createElement('a');
      link.download = `foto-${timestamp.replace(/[:.]/g, '-')}.jpg`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error downloading photo:', error);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('pt-BR');
  };

  const clearAllData = () => {
    if (confirm('Tem certeza que deseja limpar todas as sessões e fotos? Esta ação não pode ser desfeita.')) {
      localStorage.removeItem('photo-capture-sessions');
      setSessions([]);
      console.log('All data cleared');
    }
  };

  const refreshData = () => {
    setIsLoading(true);
    setTimeout(() => {
      loadSessions();
    }, 500);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-4">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 text-white animate-spin mx-auto mb-4" />
          <p className="text-white/60">Carregando dados...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Dashboard de Capturas</h1>
            <p className="text-white/60">Gerencie suas sessões de captura de foto e visualize as fotos capturadas</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={refreshData}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Atualizar
            </button>
            <button
              onClick={() => window.location.href = '/'}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Nova Sessão
            </button>
            {sessions.length > 0 && (
              <button
                onClick={clearAllData}
                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Limpar Tudo
              </button>
            )}
          </div>
        </div>

        {sessions.length === 0 ? (
          <div className="text-center py-12">
            <Camera className="w-16 h-16 text-white/30 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-white mb-2">Nenhuma Sessão Ainda</h2>
            <p className="text-white/60 mb-6">Crie sua primeira sessão de captura de foto para começar.</p>
            <button
              onClick={() => window.location.href = '/'}
              className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Criar Sessão
            </button>
          </div>
        ) : (
          <div className="grid gap-6">
            {sessions.map((session) => (
              <div key={session.id} className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-white">Sessão {session.id}</h3>
                      <span className="bg-blue-500/20 text-blue-300 px-2 py-1 rounded-full text-xs">
                        {session.photos.length} foto{session.photos.length !== 1 ? 's' : ''}
                      </span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-white/60 mb-3">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {formatDate(session.createdAt)}
                      </div>
                      <div className="flex items-center gap-1">
                        <ExternalLink className="w-4 h-4" />
                        <a 
                          href={session.originalUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="hover:text-white transition-colors truncate max-w-xs"
                        >
                          {session.originalUrl}
                        </a>
                      </div>
                    </div>
                    <div className="bg-white/5 rounded-lg p-3 border border-white/10">
                      <p className="text-white/70 text-sm break-all">
                        Link de Captura: {window.location.origin}/capture/{session.id}
                      </p>
                    </div>
                  </div>
                </div>

                {session.photos.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {session.photos.map((photo) => (
                      <div key={photo.id} className="bg-white/5 rounded-xl p-4 border border-white/10">
                        <div className="aspect-video bg-black rounded-lg overflow-hidden mb-3">
                          <img 
                            src={photo.dataUrl} 
                            alt="Foto capturada"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="text-xs text-white/60">
                            <div className="flex items-center gap-1 mb-1">
                              <Calendar className="w-3 h-3" />
                              {formatDate(photo.timestamp)}
                            </div>
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              {photo.userAgent.includes('Mobile') ? 'Mobile' : 'Desktop'}
                            </div>
                          </div>
                          <button
                            onClick={() => downloadPhoto(photo.dataUrl, photo.timestamp)}
                            className="bg-green-500 hover:bg-green-600 text-white p-2 rounded-lg transition-colors"
                            title="Baixar foto"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-white/60">
                    <Camera className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>Nenhuma foto capturada ainda</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};