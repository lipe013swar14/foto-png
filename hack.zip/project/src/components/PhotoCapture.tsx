import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Camera, CheckCircle, AlertCircle, Loader } from 'lucide-react';
import { getSession, addPhotoToSession, debugStorage } from '../utils/storage';
import { CaptureSession } from '../types';

export const PhotoCapture: React.FC = () => {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [permissionStatus, setPermissionStatus] = useState<'pending' | 'granted' | 'denied'>('pending');
  const [captureStatus, setCaptureStatus] = useState<'idle' | 'capturing' | 'success' | 'error'>('idle');
  const [countdown, setCountdown] = useState<number>(0);
  const [session, setSession] = useState<CaptureSession | null>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    console.log('PhotoCapture mounted with sessionId:', sessionId);
    debugStorage();
    
    if (!sessionId) {
      console.error('No sessionId provided');
      navigate('/');
      return;
    }

    const sessionData = getSession(sessionId);
    console.log('Session data retrieved:', sessionData);
    
    if (!sessionData) {
      console.error('Session not found for ID:', sessionId);
      setError('Session not found');
      setTimeout(() => navigate('/'), 3000);
      return;
    }

    setSession(sessionData);
    requestCameraAccess();
  }, [sessionId, navigate]);

  const requestCameraAccess = async () => {
    console.log('Requesting camera access...');
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          facingMode: 'user',
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false 
      });
      
      console.log('Camera access granted');
      setStream(mediaStream);
      setPermissionStatus('granted');
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.onloadedmetadata = () => {
          console.log('Video metadata loaded, starting countdown');
          setTimeout(() => startCountdown(), 1500);
        };
      }
      
    } catch (error) {
      console.error('Camera access denied:', error);
      setPermissionStatus('denied');
      setError('Camera access was denied. Please allow camera access and try again.');
    }
  };

  const startCountdown = () => {
    console.log('Starting countdown...');
    setCountdown(3);
    const interval = setInterval(() => {
      setCountdown(prev => {
        console.log('Countdown:', prev - 1);
        if (prev <= 1) {
          clearInterval(interval);
          setTimeout(() => capturePhoto(), 500);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current || !sessionId) {
      console.error('Missing required elements for photo capture');
      setCaptureStatus('error');
      setError('Unable to capture photo - missing required elements');
      return;
    }
    
    console.log('Starting photo capture...');
    setCaptureStatus('capturing');
    
    try {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const context = canvas.getContext('2d');
      
      if (!context) {
        throw new Error('Canvas context not available');
      }
      
      // Set canvas dimensions to match video
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      
      console.log('Canvas dimensions:', canvas.width, 'x', canvas.height);
      
      // Draw the video frame to canvas
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Convert to data URL
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      console.log('Photo captured, data URL length:', dataUrl.length);
      
      // Create photo object
      const photoData = {
        dataUrl,
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent
      };
      
      // Save photo to session
      const success = addPhotoToSession(sessionId, photoData);
      
      if (success) {
        console.log('Photo saved successfully');
        setCaptureStatus('success');
        
        // Clean up stream
        if (stream) {
          stream.getTracks().forEach(track => {
            track.stop();
            console.log('Camera track stopped');
          });
        }
        
        // Redirect after 3 seconds
        setTimeout(() => {
          if (session?.originalUrl) {
            console.log('Redirecting to:', session.originalUrl);
            window.location.href = session.originalUrl;
          } else {
            navigate('/');
          }
        }, 3000);
      } else {
        throw new Error('Failed to save photo');
      }
      
    } catch (error) {
      console.error('Photo capture failed:', error);
      setCaptureStatus('error');
      setError('Failed to capture photo. Please try again.');
    }
  };

  if (error && !session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 via-pink-900 to-rose-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Session Error</h2>
            <p className="text-white/80 mb-6">{error}</p>
            <button
              onClick={() => navigate('/')}
              className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Go Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (permissionStatus === 'pending') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
            <Loader className="w-12 h-12 text-white mx-auto mb-4 animate-spin" />
            <h2 className="text-2xl font-bold text-white mb-4">Solicitando Acesso à Câmera</h2>
            <p className="text-white/80">
              Por favor, permita o acesso à câmera para continuar. Uma foto será tirada automaticamente.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (permissionStatus === 'denied') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 via-pink-900 to-rose-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Acesso à Câmera Negado</h2>
            <p className="text-white/80 mb-6">
              O acesso à câmera é necessário para capturar uma foto. Por favor, atualize a página e permita o acesso à câmera.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Tentar Novamente
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (captureStatus === 'success') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-900 to-teal-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
            <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Foto Capturada!</h2>
            <p className="text-white/80 mb-4">
              Sua foto foi capturada e salva com sucesso.
            </p>
            <p className="text-white/60 text-sm">
              Redirecionando você para o destino original...
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (captureStatus === 'error') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 via-pink-900 to-rose-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-4">Erro na Captura</h2>
            <p className="text-white/80 mb-6">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg transition-colors"
            >
              Tentar Novamente
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-8">
          <Camera className="w-12 h-12 text-white mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-white mb-2">Captura de Foto</h1>
          <p className="text-white/80">
            Prepare-se! A foto será tirada automaticamente.
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
          <div className="relative aspect-video bg-black rounded-xl overflow-hidden mb-4">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
            
            {countdown > 0 && (
              <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                <div className="text-white text-8xl font-bold animate-pulse">
                  {countdown}
                </div>
              </div>
            )}
            
            {captureStatus === 'capturing' && (
              <div className="absolute inset-0 flex items-center justify-center bg-white/20">
                <div className="bg-white/90 rounded-full p-4 animate-pulse">
                  <Camera className="w-8 h-8 text-gray-800" />
                </div>
              </div>
            )}
          </div>

          <div className="text-center">
            {countdown > 0 ? (
              <p className="text-white/80">Tirando foto em {countdown}...</p>
            ) : captureStatus === 'capturing' ? (
              <p className="text-white/80">Capturando foto...</p>
            ) : (
              <p className="text-white/80">Preparando câmera...</p>
            )}
          </div>
        </div>

        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
};