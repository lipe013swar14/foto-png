import { CaptureSession, CapturedPhoto } from '../types';

const STORAGE_KEY = 'photo-capture-sessions';

export const generateId = (): string => {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
};

export const createSession = (originalUrl: string): CaptureSession => {
  const session: CaptureSession = {
    id: generateId(),
    originalUrl,
    createdAt: new Date().toISOString(),
    photos: []
  };
  
  const sessions = getSessions();
  sessions.push(session);
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    console.log('Session created:', session);
  } catch (error) {
    console.error('Error saving session:', error);
  }
  
  return session;
};

export const getSessions = (): CaptureSession[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    const sessions = stored ? JSON.parse(stored) : [];
    console.log('Retrieved sessions:', sessions);
    return sessions;
  } catch (error) {
    console.error('Error retrieving sessions:', error);
    return [];
  }
};

export const getSession = (id: string): CaptureSession | null => {
  try {
    const sessions = getSessions();
    const session = sessions.find(session => session.id === id) || null;
    console.log('Retrieved session:', session);
    return session;
  } catch (error) {
    console.error('Error getting session:', error);
    return null;
  }
};

export const addPhotoToSession = (sessionId: string, photo: Omit<CapturedPhoto, 'id'>): boolean => {
  try {
    const sessions = getSessions();
    const sessionIndex = sessions.findIndex(s => s.id === sessionId);
    
    if (sessionIndex !== -1) {
      const newPhoto: CapturedPhoto = {
        ...photo,
        id: generateId()
      };
      
      sessions[sessionIndex].photos.push(newPhoto);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
      console.log('Photo added to session:', newPhoto);
      return true;
    } else {
      console.error('Session not found:', sessionId);
      return false;
    }
  } catch (error) {
    console.error('Error adding photo to session:', error);
    return false;
  }
};

// Debug function to check storage
export const debugStorage = () => {
  console.log('Current storage:', localStorage.getItem(STORAGE_KEY));
  console.log('Parsed sessions:', getSessions());
};