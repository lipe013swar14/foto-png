import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LinkGenerator } from './components/LinkGenerator';
import { PhotoCapture } from './components/PhotoCapture';
import { Dashboard } from './components/Dashboard';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LinkGenerator />} />
        <Route path="/capture/:sessionId" element={<PhotoCapture />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </Router>
  );
}

export default App;