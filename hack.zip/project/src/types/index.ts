export interface CaptureSession {
  id: string;
  originalUrl: string;
  createdAt: string;
  photos: CapturedPhoto[];
}

export interface CapturedPhoto {
  id: string;
  dataUrl: string;
  timestamp: string;
  userAgent: string;
}